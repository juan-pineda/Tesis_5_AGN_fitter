/*
 *
 * This code attempts to produce the best blue galaxy SED possible.

gcc -Wall -O3 -c -I/Applications/scisoft/i386/Packages/pgplot-5.2.2/lib/ \
-I/Applications/scisoft/i386/Packages/cfitsio-3.090/include/ makefilter.c

g77 -o makefilter makefilter.o -L/usr/X11R6/lib -lX11 -Wl,-framework -Wl,Foundation -lpng -lz -laquaterm  \
-L/Applications/scisoft/i386/lib -lpgplot -lcpgplot -lcfitsio

*/

#include <cpgplot.h>
#include <fitsio.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

int main(int argc, char *argv[])  {

  long j;
  
  double mu, sigma, trans, lam;
  
  double d;
  
  FILE *fout;
  char dline[500];

  for (j=1; j<=2; j++) {
    mu=4200;
    sigma=100;
    if (j==2) {
      mu=5700;
      sigma=150;
    }

    lam=mu-2*sigma;
    d=exp(-(lam+1-mu)*(lam+1-mu)/(2.0*sigma*sigma))-exp(-(lam-mu)*(lam-mu)/(2.0*sigma*sigma));
    fprintf(stderr, "%e\n", d);
    
    sprintf(dline, "S%ld.filter", j);
    fout=fopen(dline, "w");
    fprintf(fout, "# S%ld filter used to generate photometric datapoints from spectrophotometry\n", j);
    fprintf(fout, "# Truncated Gaussian with mu=%lf Angstroms and sigma=%lf Angstroms\n", mu, sigma);
    fprintf(fout, "# Wavelength (Angstroms) and transmission\n");
    
    lam=mu-2*sigma;
    trans=exp(-(lam-mu)*(lam-mu)/(2.0*sigma*sigma));
    lam=lam-trans/d;
    trans=0;
    fprintf(fout, "%5.0lf %e\n", lam, trans);
    
    lam=mu-2*sigma;
    while (lam<mu+2*sigma+0.1) {
      trans=exp(-(lam-mu)*(lam-mu)/(2.0*sigma*sigma));
      fprintf(fout, "%5.0lf %e\n", lam, trans);
      lam=lam+10;
    }
    
    lam=mu+2*sigma;
    trans=exp(-(lam-mu)*(lam-mu)/(2.0*sigma*sigma));
    lam=lam+trans/d;
    trans=0;
    fprintf(fout, "%5.0lf %e\n", lam, trans);
    
    fclose(fout);
  }
  
  return 0;

}
