/*
 *
 * This code attempts to produce the best blue galaxy SED possible.

 * 2009 Mac laptop with scisoft

gcc -Wall -O3 -c -I/Applications/scisoft/i386/Packages/pgplot-5.2.2/lib/ \
-I/Applications/scisoft/i386/Packages/cfitsio-3.090/include/ rspconv.c

g77 -o rspconv rspconv.o -L/usr/X11R6/lib -lX11 -Wl,-framework -Wl,Foundation -lpng -lz -laquaterm  \
-L/Applications/scisoft/i386/lib -lpgplot -lcpgplot -lcfitsio

* 2011 mac laptop with ports

gcc -Wall -O3 -c -I/sw/lib/pgplot -I -I/opt/local/include/ -I/Users/brownm/code/cfitsio rspconv.c

gfortran -o rspconv rspconv.o -L/usr/X11R6/lib  \
-L/opt/local/include/ -L/usr/local/scisoft/lib/ -L/opt/local/lib \
-lX11 -Wl,-framework -Wl,Foundation -lpng -lz -laquaterm -lcpgplot -lcfitsio



*/

#include <cpgplot.h>
#include <fitsio.h>
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <time.h>

int main(int argc, char *argv[])  {
  
  FILE *fout;

  long i, j;

  fitsfile *ffin;
  int nullval=0;
  int anynul=0, status=0;
  int typecode=0;
  long repeat=0, width=0;

  float nulow[2000], nuhigh[2000], area[2000];
  long n=0;

  for (j=0; j<6; j++) {
    if (j==0) {
      fits_open_table(&ffin, "v.rsp", READONLY, &status);
      fout=fopen("swift.v.dat", "w");
    }
    if (j==1) {
      fits_open_table(&ffin, "b.rsp", READONLY, &status);
      fout=fopen("swift.b.dat", "w");
    }
    if (j==2) {
      fits_open_table(&ffin, "u.rsp", READONLY, &status);
      fout=fopen("swift.u.dat", "w");
    }
    if (j==3) {
      fits_open_table(&ffin, "uvw1.rsp", READONLY, &status);
      fout=fopen("swift.uvw1.dat", "w");
    }
    if (j==4) {
      fits_open_table(&ffin, "uvm2.rsp", READONLY, &status);
      fout=fopen("swift.uvm2.dat", "w");
    }
    if (j==5) {
      fits_open_table(&ffin, "uvw2.rsp", READONLY, &status);
      fout=fopen("swift.uvw2.dat", "w");
    }
    
    fits_get_num_rows(ffin, &n, &status);
    
    fits_get_coltype(ffin, 1, &typecode, &repeat, &width, &status);
    fits_read_col(ffin, typecode, 1, 1, 1, n, &nullval, nulow, &anynul, &status);
    
    fits_get_coltype(ffin, 2, &typecode, &repeat, &width, &status);
    fits_read_col(ffin, typecode, 2, 1, 1, n, &nullval, nuhigh, &anynul, &status);
    
    
    fits_get_coltype(ffin, 6, &typecode, &repeat, &width, &status);
    fits_read_col(ffin, typecode, 6, 1, 1, n, &nullval, area, &anynul, &status);
    
    fits_close_file(ffin, &status);
    
    
    i=n-1;
    while (i>=0) {
      fprintf(fout, "%f %e\n", 12.398521/(0.5*(nulow[i]+nuhigh[i])), area[i]);
      i--;
    }
    
    fclose(fout);

  }
  
  return 0;

}
